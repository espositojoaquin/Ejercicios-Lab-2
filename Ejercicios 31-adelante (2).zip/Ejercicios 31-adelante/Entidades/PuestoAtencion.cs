using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Entidades
{  
public  class PuestoAtencion
  {
    public enum Puesto
    {
      caja1,
      caja2
    }
    private static int numeroActual;
    private Puesto puesto;

   
    public static int NumeroActual
    {
      get { return numeroActual+1; }
     
    }

    private PuestoAtencion()
    {
      numeroActual = 0;
    }

    public PuestoAtencion(Puesto pu):this()
    {
      this.puesto = pu;
    }

    public bool Atender(Cliente cli)
    {
      bool retorno = false;
      if(object.ReferenceEquals(cli,null))
      {
        Thread.Sleep(3000);
        retorno = true;
      }
      return retorno;

    }


  }
}
