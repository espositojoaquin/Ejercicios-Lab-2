using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
 public class Negocio
  {
    private PuestoAtencion caja;
    private Queue<Cliente> clientes;
    private string nombre;

    public Cliente Clientes
    {

      get
      {
        return clientes.Dequeue();
      }

      set
      {
        bool retorno = false;
        retorno=this + value;
      
      }
    }

    private Negocio()
    {
      this.clientes = new Queue<Cliente>();
      this.caja = new PuestoAtencion(PuestoAtencion.Puesto.caja1);
    }

    public Negocio(string nombre):this()
    {
      this.nombre = nombre;
    }

    public static bool operator ~(Negocio nego)
    {
      bool retorno = false;
      if(nego.caja.Atender(nego.Clientes))
      {
        retorno = true;
      }

      return retorno;
    }

    public static bool operator+(Negocio neg, Cliente cli)
    {
      bool aux = false;
      foreach (Cliente item in neg.clientes)
      {
        if (cli == item)
        {
          aux = true;
          break;
        }
      }
      if (aux == false)
      {
        neg.clientes.Enqueue(cli);
        aux = true;
      }

      return aux;
    }

    public static bool operator ==(Negocio neg, Cliente cli)
    {
      bool retorno = false;
      if(neg.Clientes==cli)
      {
        retorno = true;
      }

      return retorno;
    }

    public static bool operator !=(Negocio neg, Cliente cli)
    {
      return !(neg == cli);
    }










  }
}
