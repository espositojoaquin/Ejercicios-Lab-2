using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;

namespace FormPrin
{
  public partial class FormClientes : Form
  {
    protected int num=0;
    protected Negocio negocio = new Negocio("Santander");
    
    public FormClientes()
    {
      InitializeComponent();
    }

    private void label1_Click(object sender, EventArgs e)
    {

    }

    private void btnAgregarCliente_Click(object sender, EventArgs e)
    {
      num++;
      Cliente cliente = new Cliente(lblNombre.Text, num);

      negocio.Clientes = cliente;
    }
  }
}
