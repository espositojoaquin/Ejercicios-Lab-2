using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;

namespace FormPrin
{ 
  public partial class FormPrincipal : Form
  {
    public int num = 0;
    public Negocio negocio = new Negocio("Santander");
   
    public FormPrincipal()
    {
      InitializeComponent();
    }

    private void richTextBox3_TextChanged(object sender, EventArgs e)
    {

    }

    private void RchAtendidos_TextChanged(object sender, EventArgs e)
    {

    }

    private void btnAgregar_Click(object sender, EventArgs e)
    {
      FormClientes agregar = new FormClientes();
      agregar.ShowDialog();
      
      Cliente cliente = new Cliente(agregar.ToString(), num);

      negocio.Clientes = cliente;
     richTextBox1.Text = agregar.ToString();
      

    }

    private void richTextBox1_TextChanged(object sender, EventArgs e)
    {
     // richTextBox1.Text = negocio.Clientes.ToString();
    }
  }
}
