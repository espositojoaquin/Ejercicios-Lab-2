using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades
{
  public class Teclado:Periferico
  {
    public enum EDistribucion
    {
      Dvorak,
      QWERTY,
      QWERTZ,
      AZERTY
    }
    #region Atributos
    private EDistribucion distribucion=EDistribucion.Dvorak;
    #endregion

    #region Constructores
    public Teclado(string marca,string modelo,EConector conector):base(marca,modelo,conector)
    {

    }
    public Teclado(string marca, string modelo, EConector conector,EDistribucion distri):this(marca,modelo,conector)
    {
      this.distribucion = distri;
    }

    #endregion

    #region Operadores
    public static bool operator ==(Teclado te, EDistribucion dis)
    {
      bool retorno = false;
      if (!(te is null) && dis!=null)
      {
        if(te.distribucion==dis)
        {
          retorno = true;
        }
      }
      return retorno;
    }

    public static bool operator !=(Teclado te, EDistribucion dis)
    {

      return !(te == dis);
    }
    #endregion

    #region Metodos
    public override string ExponerDatos()
    {
      StringBuilder sb = new StringBuilder();
      Periferico p = (Periferico)this;
      sb.AppendLine($"{(string)p}");
        sb.AppendLine($"Distribucion: {this.distribucion}");
      return sb.ToString();
    }
    #endregion
  }
}
