using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades
{
    public  class PlacaVideo:Periferico
    {
        #region Atributos
        private int ramMB;

        #endregion

        #region Constructores
    public PlacaVideo(string marca,string modelo,int ramMB):base(marca,modelo,EConector.PCIExpress)
    {
      this.ramMB = ramMB;
    }
    #endregion

       #region Operadores
    #endregion

        #region Metodos
    public override string ExponerDatos()
    {
      {
        StringBuilder sb = new StringBuilder();
        Periferico p = (Periferico)this;
        sb.AppendLine($"{(string)p}\nRamMB: {this.ramMB}");
        return sb.ToString();
      }
    }
    #endregion
  }
}
