using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades
{
 public class Maquina
  {
    #region Atributos
    private int CantidadMaxPerifericos;
    private string nombre;
    private List<Periferico> perifericos;
    #endregion

    #region Propiedades
    public int CantidadMaximaPerifericos
    {
      get
      {
        return this.CantidadMaxPerifericos;
      }
      set
      {
        if (value > 1 && value < 4)
        {
          this.CantidadMaxPerifericos = value;
        }
        else
        {
          if (value < 1)
          {
            this.CantidadMaxPerifericos = 1;
          }
          else
          {
            this.CantidadMaxPerifericos = 4;
          }
        }
      }
    }

    public string Nombre
    {
      get
      {
        return this.nombre;
      }
      set
      {
        this.nombre = value;
      }

    }
    public string SystemInfo
    {
      get
      {

        StringBuilder sb = new StringBuilder();

        sb.AppendLine($"{this.nombre}\n");
        sb.AppendLine("Lista de Perifericos\n*****************\n");
        foreach (Periferico item in this.perifericos)
        {
         
            sb.AppendLine($"{item.ExponerDatos()}");     
        
        }
       

        return sb.ToString();
      }
    }
    #endregion

    #region Constructores
    private Maquina()
    {
      this.perifericos = new List<Periferico>();
      this.CantidadMaximaPerifericos = 3;
    }

    public Maquina(string nombre) : this()
    {
      this.nombre = nombre;
    }
    #endregion

    #region Operadores
    public static bool operator ==(Maquina ma, Periferico peri)
    {
      bool retorno = false;
      if (!(ma is null) && !(peri is null))
      {
        foreach (Periferico item in ma.perifericos)
        {
          if (item == peri)
          {
            retorno = true;
            break;
          }
        }
      }
      return retorno;

    }
    public static bool operator !=(Maquina ma, Periferico peri)
    {
      return !(ma == peri);
    }

    public static string operator +(Maquina ma, Periferico peri)
    {
      string retorno="No se puede conectar el dispositivo";
      if (ma.perifericos.Count < ma.CantidadMaximaPerifericos) 
      {
        if (ma != peri)
        {

          ma.perifericos.Add(peri);
          retorno = "Periferico Conectado";
          
        }
      }
      return retorno;

    }
    public static string operator -(Maquina ma, Periferico peri)
    {
      string retorno = "No se puede desconectar el dispositivo";

      for(int i =0; i<ma.perifericos.Count; i ++)
      {
        if(peri==ma.perifericos[i])
        {
          // ma.perifericos.Remove(ma.perifericos[i]);
          ma.perifericos.RemoveAt(i);
          retorno = "Dispositivo Desconectado";


          break;
        }
      }
      
      return retorno;

    }
    #endregion

    #region Metodos
    #endregion
  }
}
