using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades
{
   public enum EConector
   { PCIExpress,
     USB,
     MiniUSB,
     MicroUSB,
     PS2
   }
  public abstract class Periferico
  {
    #region Atributos
    private EConector conector;
    private string marca;
    private string modelo;

    #endregion


    #region Constructores
    public Periferico(string marca,string modelo,EConector conector)
    {
      this.marca = marca;
      this.modelo = modelo;
      this.conector = conector;
    }
    #endregion

    #region Operadores
    public static bool operator ==(Periferico per1, Periferico per2)
    {
      bool retorno = false;
      if (!(per1 is null) && !(per2 is null))
      {
        if (per1.marca == per2.marca&&per1.modelo==per2.modelo)
        {
          retorno = true;
        }
      }
      return retorno;
    }

    public static bool operator !=(Periferico per1, Periferico per2)
    {
  
        return !(per1 == per2);
    }

    public static explicit operator string(Periferico peri)
    {
      StringBuilder sb = new StringBuilder();
      
      sb.AppendFormat($"Marca:{peri.marca}\nModelo: {peri.modelo}\nConector:{peri.conector}\n");
      
      return  sb.ToString();
    }
    #endregion

    #region Metodos
    public abstract string ExponerDatos();
    #endregion
  }
}
