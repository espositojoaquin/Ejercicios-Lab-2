using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
  public class Pesos
  {
    private double cantidad;
    private static float cotizRespectoDolar;

    private Pesos()
    {
      this.cantidad = 0;
      cotizRespectoDolar = (float)38.33;
    }

    public Pesos(double cantidad) : this()
    {
      this.cantidad = cantidad;
    }

    public Pesos(double cantidad, float cotizacion) : this(cantidad)
    {

    }

    public double GetCantidad()
    {

      return this.cantidad;

    }

    public static float GetCotizacion()
    {
      return cotizRespectoDolar;

    }

    public static explicit operator Dolar(Pesos pes)
    {
      Dolar dol = new Dolar(pes.cantidad * cotizRespectoDolar);
      return dol;
    }

    public static explicit operator Euro(Pesos pes)
    {
      Euro eur = new Euro(pes.cantidad * Euro.GetCotizacion());
      return eur;
    }

    public static implicit operator Pesos(double p)
    {
      Pesos pes = new Pesos(p);
      return pes;
    }

    public static Pesos operator +(Pesos p, Dolar d)
    {
      Pesos pes = new Pesos();

      return p.cantidad + (((Pesos)d).GetCantidad());
    }

    public static Pesos operator -(Pesos p, Dolar d)
    {
      Pesos pes = new Pesos();

      return p.cantidad - (((Pesos)d).GetCantidad());
    }

    public static bool operator==(Pesos pe,Dolar dol)
    {
      bool retorno = false;
      if (pe.cantidad*cotizRespectoDolar == dol.GetCantidad())
      {
        retorno = true;
      }
      return retorno;
    }
    


















  }
}
