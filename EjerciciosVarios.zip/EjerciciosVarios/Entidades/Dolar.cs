using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
 public class Dolar
  {
    private double cantidad;
    private static float cotizRespectoDolar;
    private Dolar()
    {
      this.cantidad = 0;
      cotizRespectoDolar = 1;
    }

    public Dolar(double cantidad) : this()
    {
      this.cantidad = cantidad;
    }

    public Dolar(double cantidad, float cotizacion) : this(cantidad)
    {

    }

    public double GetCantidad()
    {
      
        return this.cantidad;
      
    }

    public static float GetCotizacion()
    {
      
        return cotizRespectoDolar;
      
    }

    public static explicit operator Pesos(Dolar dol)
    {
      Pesos pe = new Pesos(dol.cantidad *Pesos.GetCotizacion() );

      return pe;
    }

    public static explicit operator Euro(Pesos pes)
    {
      Euro eur = new Euro(pes.cantidad * pes.cotizRespectoDolar);
      return eur;
    }

    public static implicit operator Pesos(double p)
    {
      Pesos pes = new Pesos(p);
      return pes;
    }
  }
}
