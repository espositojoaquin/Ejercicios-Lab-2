using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
  public class Euro
  {
    private double cantidad;
    private float cotizRespectoDolar = (float)1.16;

    private Euro()
    {
      this.cantidad = 0;
    }

    public Euro(double cantidad) : this()
    {
      this.cantidad = cantidad;
    }

    public Euro(double cantidad, float cotizacion) : this(cantidad)
    {
      this.cotizRespectoDolar = cotizacion;
    }

    public double GetCantidad()
    {
      
        return this.cantidad;
      
    }

    public static float GetCotizacion()
    {
     
        return this.cotizRespectoDolar;
      
    }
  }
}
