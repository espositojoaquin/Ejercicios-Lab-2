using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
  public class Numero
  {
    private double numero;

    public Numero()
    {
      this.numero = 0;
    }
    public Numero(double numero)
    {
      this.numero = numero;
    }

    public string SetNumero
    {
      set
      {
        this.numero=ValidarNumero(value);
      }
    }

    public Numero(string strNumero)
    {
      this.SetNumero = strNumero;
    }

    private double ValidarNumero(string strNumero)
    { 
      double retorno;
      if(!(double.TryParse(strNumero, out retorno)))
      {
        retorno = 0;
      }

      return retorno;
    }


 


     




  }
}
