﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades
{
    public abstract class Animales
    {
        #region Atributos
        protected int cantidadPatas;
        protected static Random distanciaRecorrida;
        protected int velocidadMaxima;
        #endregion

        #region Propeades
        public int CantidadPatas
        {
            get
            {
                return this.cantidadPatas;
            }
            set
            {
                if (value < 5)
                {
                    this.cantidadPatas = value;
                }
                else
                {
                    this.cantidadPatas = 4;
                }
            }
        }

        protected static int DistanciaRecorrida
        {
            get
            {
                return distanciaRecorrida.Next(10,60);
            }
        }

        public int VelocidadMaxima
        {
            get
            {
                return this.velocidadMaxima;
            }
            set
            {
                if (value < 61)
                {
                    this.velocidadMaxima = value;
                }
                else
                {
                    this.velocidadMaxima = 60;
                }
            }
        }
        #endregion

        #region Comstructores
        private Animales()
        {
            Animales.distanciaRecorrida = new Random();
        }
        public Animales(int cantidadPatas,int velocidadMax):this()
        {
            this.CantidadPatas = cantidadPatas;
            this.VelocidadMaxima = velocidadMax;
        }
        #endregion

        #region Metodos
        public virtual string  MostrarDatos()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"Cantidad de Patas: {this.CantidadPatas}\nDistancia Recorrida: {Animales.DistanciaRecorrida}\nVelocidad Maxima: {this.VelocidadMaxima}");
            return sb.ToString();
        }
        #endregion


    }
}
