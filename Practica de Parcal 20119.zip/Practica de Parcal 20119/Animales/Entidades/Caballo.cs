﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades
{
    public class Caballo:Animales
    {
        #region Atributos
        private string nombre;
        private static int patas;
        #endregion

        #region Constructores
        static Caballo()
        {
            Caballo.patas = 4;
        }
        public Caballo(string nombre,int velocidad):base(Caballo.patas,velocidad)
        {
            this.nombre = nombre;
        }
        #endregion

        #region Operadores
        public static bool operator ==(Caballo cab1, Caballo cab2)
        {
            bool retorno = false;


            if (cab1.nombre == cab2.nombre)
            {
                retorno = true;

            }

            return retorno;
        }

        public static bool operator !=(Caballo cab1, Caballo cab2)
        {
            return !(cab1 == cab2
);
        }
        #endregion

        #region Metodos
        public override string MostrarDatos()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"Caballo\n********\n{base.MostrarDatos()}Nombre: {this.nombre}");
            return sb.ToString();
        }
        #endregion

    }
}
