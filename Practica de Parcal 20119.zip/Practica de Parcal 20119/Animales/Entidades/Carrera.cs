﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades
{
    public class Carrera
    {
        #region Atributos
        private List<Animales> animales;
        private int corredoresMax;
        #endregion

        #region Costructores
        private Carrera()
        {
            this.animales = new List<Animales>();
        }

        public Carrera(int corredores) : this()
        {
            this.corredoresMax = corredores;

        }
        #endregion

        #region Operadores
        public static bool operator ==(Carrera car, Animales ani)
        {
            bool retorno = false;

            foreach (Animales item in car.animales)
            {
                if (item == ani)
                {
                    retorno = true;
                    break;
                }
            }

            return retorno;
        }
        public static bool operator !=(Carrera car, Animales ani)
        {
            return !(car == ani);
        }
        /// <summary>
        /// Agrega un elemento si no se encueta en la lista
        /// </summary>
        /// <param name="car"></param>
        /// <param name="ani"></param>
        /// <returns></returns> la lista con el elemento retornado 
        public static Carrera operator +(Carrera car, Animales ani)
        {
            if (car.animales.Count < car.corredoresMax)
            {
                if (!(ani is null))
                {
                    if (car != ani)
                    {
                        car.animales.Add(ani);
                    }
                }
            }

            return car;
        }

        #endregion

        #region Metodos 
        public string Mostrar()
        {
        
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("CARRERA\n*****************");
            sb.AppendLine($"Cantidad Maxima de Corredores:{this.corredoresMax}\n");
            sb.AppendLine("Lista de Competidores\n*************************\n");
            for (int i = 0; i < this.animales.Count; i++)
            {
                sb.AppendLine($"{this.animales[i].MostrarDatos()}");
            }

            return sb.ToString();
        }
        #endregion
    }
}
