﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades
{
    public class Perro:Animales
    {
        #region Enumerado
        public enum Razas
        {
            Galgo,
            OvejeroAleman
        }
        #endregion

        #region Atributos
        private static int patas;
        private Razas razas;
        #endregion

        #region Constructores
        static Perro()
        {
            Perro.patas = 4;
        }

        public Perro(int velocidad):base(Perro.patas,velocidad)
        {

        }
        public Perro(Razas raza, int velocidadMaxima):this(velocidadMaxima)
        {
            this.razas = raza;
        }
        #endregion

        #region Operadores
        public static bool operator ==(Perro per1, Perro per2)
        {
            bool retorno = false;


            if (per1.razas == per2.razas && per1.VelocidadMaxima == per2.VelocidadMaxima)
            {
                retorno = true;

            }

            return retorno;
        }

        public static bool operator !=(Perro per1, Perro per2)
        {
            return !(per1 == per2);
        }

        #endregion

        #region Metodos
        public override string MostrarDatos()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"Perro\n********\n{base.MostrarDatos()}Raza: {this.razas}");
            return sb.ToString();
        }
        #endregion


    }
}
