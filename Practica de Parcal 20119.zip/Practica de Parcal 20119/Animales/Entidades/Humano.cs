﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades
{
    public class Humano : Animales
    {
        #region Atributos
        private string nombre;
        private string apellido;
        private static int piernas;
        #endregion

        #region Constructores
        static Humano()
        {
            Humano.piernas = 2;
        }
        public Humano(int velocidad):base(Humano.piernas,velocidad)
        {

        }
        public Humano(string nombre, string apellido, int velocidadMaxima) : base(Humano.piernas, velocidadMaxima)
        {
            this.nombre = nombre;
            this.apellido = apellido;
        }
        #endregion

        #region Operadores
        public static bool operator ==(Humano hum1, Humano hum2)
        {
            bool retorno = false;

       
                if (hum1.nombre==hum2.nombre&&hum1.apellido==hum2.apellido)
                {
                    retorno = true;
                    
                }
            
            return retorno;
        }

        public static bool operator !=(Humano hum1, Humano hum2)
        {
            return !(hum1== hum2);
        }
        #endregion

        #region Metodos
        public override string MostrarDatos()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"Humano\n********\n{base.MostrarDatos()}Nombre: {this.nombre}\nApellido: {this.apellido}\n");
            return sb.ToString();

        }
        #endregion


    }
}
