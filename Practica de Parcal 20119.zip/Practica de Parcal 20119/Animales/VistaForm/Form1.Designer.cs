﻿namespace VistaForm
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnPruebaClases = new System.Windows.Forms.Button();
            this.btnSalida = new System.Windows.Forms.Button();
            this.rtbSalida = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // btnPruebaClases
            // 
            this.btnPruebaClases.Location = new System.Drawing.Point(12, 39);
            this.btnPruebaClases.Name = "btnPruebaClases";
            this.btnPruebaClases.Size = new System.Drawing.Size(389, 53);
            this.btnPruebaClases.TabIndex = 0;
            this.btnPruebaClases.Text = "Pueba Clases";
            this.btnPruebaClases.UseVisualStyleBackColor = true;
            this.btnPruebaClases.Click += new System.EventHandler(this.btnPruebaClases_Click);
            // 
            // btnSalida
            // 
            this.btnSalida.Location = new System.Drawing.Point(12, 98);
            this.btnSalida.Name = "btnSalida";
            this.btnSalida.Size = new System.Drawing.Size(389, 50);
            this.btnSalida.TabIndex = 1;
            this.btnSalida.Text = "Mostrar Salida por Pantalla";
            this.btnSalida.UseVisualStyleBackColor = true;
            this.btnSalida.Click += new System.EventHandler(this.btnSalida_Click);
            // 
            // rtbSalida
            // 
            this.rtbSalida.Location = new System.Drawing.Point(1, 154);
            this.rtbSalida.Name = "rtbSalida";
            this.rtbSalida.Size = new System.Drawing.Size(406, 296);
            this.rtbSalida.TabIndex = 2;
            this.rtbSalida.Text = "";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(413, 450);
            this.Controls.Add(this.rtbSalida);
            this.Controls.Add(this.btnSalida);
            this.Controls.Add(this.btnPruebaClases);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnPruebaClases;
        private System.Windows.Forms.Button btnSalida;
        private System.Windows.Forms.RichTextBox rtbSalida;
    }
}

