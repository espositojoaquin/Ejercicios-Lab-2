﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Entidades;

namespace VistaForms
{ 
    public partial class Form1 : Form
    {
        RobotSirviente robot;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCrear_Click(object sender, EventArgs e)
        {
            this.robot = new RobotSirviente(Convert.ToInt32(txtEnergia.Text), txtOrigen.Text);

            MessageBox.Show( $"Codigo:{NUPCodigo.Text}\nEnergia:{this.robot.Energia}\nOrigen:{txtOrigen.Text}","Creacion de Robot" );


        }
    }
}
