﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades
{
    public class RobotSirviente:Robot
    {
        #region Costructores
        public RobotSirviente():base()
        {

        }

        public RobotSirviente(int energia,string origen)
            :base(energia,origen)
        {

        }
        #endregion

        #region Metodos
        public override bool CargarEnergia(int energia)
        {
            bool retorno=false;

            if(this.energia==0)
            {
               retorno= base.CargarEnergia(energia);
            }

            return retorno;
        }

        public override string ServirHumanidad()
        {
            string retorno = $"Robot de servicio {this.Codigo} sin Energia";

            if (this.energia > 0)
            {
                this.energia -= 1;

                retorno = $"Robot de combate {this.Codigo} haciendo masajes";
            }
            return retorno;
        }
        #endregion
    }
}
