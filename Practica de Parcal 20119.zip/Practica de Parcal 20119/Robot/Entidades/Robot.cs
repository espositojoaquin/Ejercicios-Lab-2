﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades
{
    public abstract class Robot
    {
        #region Atributos
        protected static int capacidadEnergia;
        private static int contador;
        private int codigo;
        protected int energia;
        protected string origen;
        #endregion

        #region Propiedades
        public static int CapacidadEnergia
        {
            get
            {
                return Robot.capacidadEnergia;
            }
        }

        public int Codigo
        {
            get
            {
                return this.codigo;
            }
        }

        public int Energia
        {
            get
            {
                return this.energia
;
            }
        }

        #endregion

        #region Constructores
        static Robot()
        {
            Robot.capacidadEnergia = 50;
            Robot.contador = 0;
        }

        protected Robot()
        {
            this.origen = "Coreano";
            this.energia = 10;
            Robot.contador += 1;
            this.codigo = contador;
        }

        public Robot(int energia, string origen) : this(
)
        {
            this.energia = energia;
            this.origen = origen;
        }
        #endregion

        #region Metodos
        public virtual bool CargarEnergia(int energia)
        {
            bool retorno = false;

            if (energia > 0 && energia < Robot.capacidadEnergia)
            {
                retorno = true;
            }

            return retorno;
        }

        public static bool operator ==(Robot rob1, Robot rob2)
        {
            bool retorno = false;
            if (!(rob1 is null) && !(rob2 is null))
            {
                if (rob1.Codigo == rob2.Codigo)
                {
                    retorno = true;
                }
            }
            return retorno;
        }

        public static bool operator !=(Robot rob1, Robot rob2)
        {
            bool retorno=false;
            if(!(rob1 is null) && !(rob2 is null))
            {
                retorno =!(rob1 == rob2);
                
            }
            return retorno;
        }

        public abstract string ServirHumanidad();

        #endregion




    }
}
