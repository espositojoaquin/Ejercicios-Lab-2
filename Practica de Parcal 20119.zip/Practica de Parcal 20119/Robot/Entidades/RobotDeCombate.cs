﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades
{
    public class RobotDeCombate : Robot
    {
        #region Atributos
        private int calballosDeFuerza;
        private bool lucho;
        #endregion

        #region Propiedades
        public int CaballosDeFuerza
        {
            get
            {
               return this.calballosDeFuerza;
            }
        }

        public bool Lucho
        {
            get
            {
              return  this.lucho;
            }
        }
        #endregion

        #region Constructores
        public RobotDeCombate():base()
        {
            this.lucho = false;
        }
        public RobotDeCombate(int enregia, string origen):base(enregia,origen)
        {
            this.calballosDeFuerza = 10;
            this.lucho = false;
        }

        public RobotDeCombate(int enregia, string origen,int caballos):this(enregia,origen)
        {
            this.calballosDeFuerza = caballos;
        }

        #endregion

        #region Metodos
        public override string ServirHumanidad()
        {
            string retorno=$"Robot de combate {this.Codigo} sin Energia";

            if(this.energia>0)
            {
                this.energia -= 1;

                retorno= $"Robot de combate {this.Codigo} Disparando Misiles";
            }
            return retorno;
        }
        #endregion


    }
}
