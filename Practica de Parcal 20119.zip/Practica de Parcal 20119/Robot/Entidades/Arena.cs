﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades
{
    public class Arena
    {
        #region Atributos
        public int espacioDisponible;
        public string nombre;
        public List<RobotDeCombate> robotsDeCombate;
        public List<RobotSirviente> robotsSirvientes;
        #endregion

        #region Costructores
        private Arena()
        {
            this.robotsDeCombate = new List<RobotDeCombate>();
            this.robotsSirvientes = new List<RobotSirviente>();
        }
        public Arena(string nombre, int espacioDisponible) : this()
        {
            this.nombre = nombre;
            this.espacioDisponible = espacioDisponible;
        }
        #endregion

        #region Operadores
        public static bool operator ==(Arena are, Robot rob)
        {
            bool retorno = false;
            if (rob is RobotDeCombate)
            {
                foreach (RobotDeCombate item in are.robotsDeCombate)
                {
                    if (item == rob)
                    {
                        retorno = true;
                        break;
                    }
                }
            }
            else if (rob is RobotSirviente)
            {
                foreach (RobotSirviente item in are.robotsSirvientes)
                {
                    if (item == rob)
                    {
                        retorno = true;
                        break;
                    }
                }
            }

            return retorno;

        }

        public static bool operator !=(Arena are, Robot rob)
        {
            return !(are == rob);
        }

        public static Arena operator +(Arena are, Robot rob)
        {
            if (are != rob)
            {
                if (rob is RobotDeCombate)
                {
                    are.robotsDeCombate.Add((RobotDeCombate)rob);
                }
                else
                {
                    are.robotsSirvientes.Add((RobotSirviente)rob);
                }
            }
            return are;
        }
        public static Arena operator -(Arena are, Robot rob)
        {
            if (are == rob)
            {
                if (rob is RobotDeCombate)
                {
                    are.robotsDeCombate.Remove((RobotDeCombate)rob);
                }
                else
                {
                    are.robotsSirvientes.Remove((RobotSirviente)rob);
                }
            }
            return are;
        }

        #endregion

        #region Metodos
        public string ServirEspectadores()
        {
            string retorno = "";
            foreach (RobotSirviente item in this.robotsSirvientes)
            {
                if (item.Energia > 0)
                {
                    retorno = item.ServirHumanidad();
                    break;
                }
            }

            return retorno;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"{this.nombre}\n");
            sb.AppendLine("Lista de robots de Combate\n*****************\n");
            foreach (RobotDeCombate item in this.robotsDeCombate)
            {
                sb.AppendLine($"{item.ServirHumanidad()}");
            }
            sb.AppendLine("Lista de robots de Servicio\n*****************\n");
            foreach (RobotSirviente item in this.robotsSirvientes)
            {
                sb.AppendLine($"{item.ServirHumanidad()}");
            }

            return sb.ToString();
        }

        public static implicit operator string(Arena arena)
        {
            return arena.ToString();
        }

        public string Combate(RobotDeCombate combatiente)
        {
            StringBuilder sb = new StringBuilder();
            if(!(combatiente is null) && combatiente.Energia>0)
            {
                foreach (RobotDeCombate item in this.robotsDeCombate)
                {
                    if(item.Energia>0)
                    {
                        sb.AppendLine($"Robot coombatiente:{combatiente.ServirHumanidad()}\n Robot desafiante:{item.ServirHumanidad()}");
                        if(combatiente.CaballosDeFuerza>item.CaballosDeFuerza)
                        {
                            sb.AppendLine($"El ganador es Robot combatiene {combatiente.Codigo}");
                            break;
                        }
                        else
                        {
                            if(item.CaballosDeFuerza>combatiente.CaballosDeFuerza)
                            {
                                sb.AppendLine($"El ganador es Robot desafio {item.Codigo}");
                                break;
                            }
                            else
                            {
                                sb.AppendLine($"Robot combatiente{combatiente.Codigo} y robot desafio{item.Codigo} han empatado");
                                break;
                            }
                        }
                    }
                    else
                    {
                        sb.AppendLine("No se encontro oponente");
                    }
                }
            }

            return sb.ToString();
        }
        #endregion
    }
}
