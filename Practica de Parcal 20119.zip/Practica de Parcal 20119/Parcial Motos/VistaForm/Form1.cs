﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Entidades;

namespace VistaForm
{
    public partial class Form1 : Form
    {
        PickUp Pick;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCrear_Click(object sender, EventArgs e)
        {
            Pick = new PickUp(txtPatente.Text, txtModelo.Text);

            /* MessageBox.Show($"{Pick.ConsultarDatos()}");*/
            MessageBox.Show(Pick.ConsultarDatos(),"PikUp",MessageBoxButtons.OKCancel,MessageBoxIcon.Information);
        }
    }
}
