﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades
{
    public class Moto : Vehiculo
    {
        #region Atributos
        private int cilindradra;
        private short ruedas = 2;
        private static int valorhora;

        #endregion

        #region Constructores
        static Moto()
        {
            valorhora = 30;
        }

        public Moto(string patente, int cilin) : base(patente)
        {
            this.cilindradra = cilin;
        }

        public Moto(string patente, int cilindrada, short ruedas) : this(patente, cilindrada)
        {
            this.ruedas = ruedas;
        }

        public Moto(string patente, int cilindrada, short ruedas, int valor) : this(patente, cilindrada, ruedas)
        {
            valorhora = valor;
        }



        #endregion

        #region Metodos

        public override bool Equals(object obj)
        {
            return obj is Moto;
        }

        public override string ConsultarDatos()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Moto");
            sb.AppendLine($"{base.ImprimirTiket()}Cilindrada: {this.cilindradra}\nRueadas: {this.ruedas}");
          return  sb.ToString();
        }

        public override string ImprimirTiket()
        {
            double resultado=(DateTime.Now-this.ingreso).TotalHours*valorhora;

            return this.ConsultarDatos()+$"Costo de Estadia:{resultado}\n\n";
        }


        #endregion


    }
}
