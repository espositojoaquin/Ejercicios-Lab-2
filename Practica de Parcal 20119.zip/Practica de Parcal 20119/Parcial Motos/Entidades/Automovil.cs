﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades
{
    public class Automovil : Vehiculo
    {
        #region Atributos
        private ConsoleColor color;
        private static int valorHora;
        #endregion

        #region Costructores
        static Automovil()
        {
            valorHora = 50;
        }

        public Automovil(string patente,ConsoleColor color):base(patente)
        {
            this.color = color;
        }

        public Automovil(string patente, ConsoleColor color,int valorH):this(patente,color)
        {
            valorHora = valorH;
        }


        #endregion

        #region Metodos
        public override bool Equals(object obj)
        {
            return obj is Automovil;
        }

        public override string ConsultarDatos()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Auto");
            sb.AppendLine($"{base.ImprimirTiket()}Color: {this.color}");

           return sb.ToString();
        }

        public override string ImprimirTiket()
        {
            double resultado = (DateTime.Now - this.ingreso).TotalHours * valorHora;

            return this.ConsultarDatos() + $"Costo de Estadia:{resultado}\n\n";
        }
        #endregion

    }
}
