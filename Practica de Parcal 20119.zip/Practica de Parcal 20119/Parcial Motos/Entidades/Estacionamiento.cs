﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades
{
    public class Estacionamiento
    {
        #region Atribiutos
        private int espacioDisponible;
        private string nombre;
        private List<Vehiculo> vehiculos;
        #endregion

        #region Costructores
        private Estacionamiento()
        {
            this.vehiculos = new List<Vehiculo>();
        }

        public Estacionamiento(string nombre, int espacio) : this()
        {
            this.nombre = nombre;
            this.espacioDisponible = espacio;

        }
        #endregion

        #region Metodos
        public static explicit operator string(Estacionamiento est)
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"Nombre:{est.nombre}\nCapacidad:{est.espacioDisponible}");
            if (est.vehiculos.Count > 0)
            {
                sb.AppendLine("Lista de Vehiculos\n===================");
                foreach (Vehiculo item in est.vehiculos)
                {
                    sb.AppendLine(item.ConsultarDatos());
                }
            }
            else
            {
                sb.AppendLine("El Estacionamiento se encuentra vacio");
            }

            return sb.ToString();
        }

        public static bool operator ==(Estacionamiento est, Vehiculo vehi)
        {
            bool retorno = false;

            foreach (Vehiculo item in est.vehiculos)
            {
                if (item == vehi)
                {
                    retorno = true;
                    break;
                }
            }

            return retorno;
        }
        public static bool operator !=(Estacionamiento est, Vehiculo vehi)
        {
            return !(est == vehi);
        }

        public static Estacionamiento operator +(Estacionamiento est, Vehiculo vehi)
        {
            if (est.vehiculos.Count < est.espacioDisponible)
            {
                if (vehi.Patente != null)
                {
                    if (est != vehi)
                    {
                        est.vehiculos.Add(vehi);
                    }
                }
            }

            return est;
        }

        public static string operator -(Estacionamiento est, Vehiculo vehi)
        {
            string retorno = "El vehiculo no es parte del Estacionamiento";

            if (est == vehi)
            {
                retorno = vehi.ImprimirTiket();
                est.vehiculos.Remove(vehi);
            }

            return retorno;
        }





        #endregion

    }
}
