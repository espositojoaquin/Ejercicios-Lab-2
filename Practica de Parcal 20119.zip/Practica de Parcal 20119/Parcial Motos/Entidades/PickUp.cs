﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades
{
    public class PickUp:Vehiculo
    {
        #region Atributos
        private string modelo;
        private static int valorHora;
        #endregion

        #region Costructores
        static PickUp()
        {
            valorHora = 70;
        }

        public PickUp(string patente, string modelo) : base(patente)
        {
            this.modelo = modelo;
        }
        public PickUp(string patente, string modelo, int valorH) : this(patente, modelo)
        {
            valorHora = valorH;
        }


        #endregion

        #region Metodos
        public override bool Equals(object obj)
        {
            return obj is PickUp;
        }

        public override string ConsultarDatos()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("PickUp");
            sb.AppendLine($"{base.ImprimirTiket()}Modelo: {this.modelo}");

            return sb.ToString();
        }

        public override string ImprimirTiket()
        {
            double resultado = (DateTime.Now - this.ingreso).TotalHours * valorHora;

            return this.ConsultarDatos() + $"Costo de Estadia:{resultado}\n\n";
        }
        #endregion


    }
}
