﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades
{
    public abstract class Vehiculo
    {
        #region Atributos
        protected DateTime ingreso;
        private string patente;
        #endregion

        #region Propiedades
        public string Patente
        {
            get
            {       
                    return this.patente;
            }
            set
            {
                if(value.Length==6)
                {
                    this.patente = value;
                }
            }
        }
        #endregion

        #region Metodos
        public Vehiculo(string pat)
        {
            this.ingreso = DateTime.Now.AddHours(-3);
            this.Patente = pat;
        }

        public static bool operator ==(Vehiculo veh1,Vehiculo vehi)
        {
            bool retorno = false;
              
            if(veh1.Patente==vehi.Patente&&Equals(veh1,vehi))
            {
                retorno = true;
            }
            return retorno;
        }

        public static bool operator !=(Vehiculo veh1, Vehiculo vehi)
        {
            return !(veh1 == vehi);
        }

        public override string ToString()
        {
            return string.Format($"Patente: {this.Patente}");
        }
        public abstract string ConsultarDatos();

        public virtual string ImprimirTiket()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"{this}\nFecha:{this.ingreso}");

            return sb.ToString();
        }

        



        #endregion

    }
}
