﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EntidadesReutilizable
{
    public class Reutilizacion
    {
        #region Costructores
        /* static Moto()
          {
              valorhora = 30;
          }

          public Moto(string patente, int cilin) : base(patente)
          {
              this.cilindradra = cilin;
          }

          public Moto(string patente, int cilindrada, short ruedas) : this(patente, cilindrada)
          {
              this.ruedas = ruedas;
          }

          public Moto(string patente, int cilindrada, short ruedas, int valor) : this(patente, cilindrada, ruedas)
          {
              valorhora = valor;
          }


        static Robot()
        {
            Robot.capacidadEnergia = 50;
            Robot.contador = 0;
        }

        protected Robot()
        {
            this.origen = "Coreano";
            this.energia = 10;
            Robot.contador += 1;
            this.codigo = contador;
        }

        public Robot(int energia, string origen) : this()
        {
            this.energia = energia;
            this.origen = origen;
        }
          
         */

        #endregion

        #region Propiedades
        /* public DirectorTecnico DirectorTecnico
         {
             set
             {
                 if (value != null)
                 {
                     if (value.ValidarAptitud())
                     {
                         this.directorTecnico = value;
                     }
                 }


             }
         }*/
        #endregion

        #region Operador == y !=


        public static bool operator ==(Robot rob1, Robot rob2)
        {
            bool retorno = false;
            if (!(rob1 is null) && !(rob2 is null))
            {
                if (rob1.Codigo == rob2.Codigo)
                {
                    retorno = true;
                }
            }
            return retorno;
        }

        public static bool operator !=(Robot rob1, Robot rob2)
        {
            bool retorno = false;
            if (!(rob1 is null) && !(rob2 is null))
            {
                retorno = !(rob1 == rob2);

            }
            return retorno;
        }
        //***********************************************************************************
        public static bool operator ==(Arena are, Robot rob)
        {
            bool retorno = false;
            if (rob is RobotDeCombate)
            {
                foreach (RobotDeCombate item in are.robotsDeCombate)
                {
                    if (item == rob)
                    {
                        retorno = true;
                        break;
                    }
                }
            }
            else if (rob is RobotSirviente)
            {
                foreach (RobotSirviente item in are.robotsSirvientes)
                {
                    if (item == rob)
                    {
                        retorno = true;
                        break;
                    }
                }
            }

            return retorno;

        }

        public static bool operator !=(Arena are, Robot rob)
        {
            return !(are == rob);
        }
        //***********************************************************************************
        public static bool operator ==(Estacionamiento est, Vehiculo vehi)
        {
            bool retorno = false;

            foreach (Vehiculo item in est.vehiculos)
            {
                if (item == vehi)
                {
                    retorno = true;
                    break;
                }
            }

            return retorno;
        }
        public static bool operator !=(Estacionamiento est, Vehiculo vehi)
        {
            return !(est == vehi);
        }
        //************************************************************************************
        public static bool operator ==(Equipo equi, Jugador jug)
        {
            bool retorno = false;

            foreach (Jugador item in equi.jugadores)
            {
                if (item == jug)
                {
                    retorno = true;
                    break;
                }
            }
            return retorno;
        }

        public static bool operator !=(Equipo equi, Jugador jug)
        {
            return !(equi == jug);
        }
        #endregion

        #region Operador +
        public static Equipo operator +(Equipo equi, Jugador jug)
        {
            if (equi.jugadores.Count < Equipo.cantidadMaximaJugador)
            {
                if (equi != jug)
                {
                    if (jug.ValidarAptitud())
                    {
                        equi.jugadores.Add(jug);
                    }
                }
            }

            return equi;

        }
        //********************************************************************************
        public static Arena operator +(Arena are, Robot rob)
        {
            if (are != rob)
            {
                if (rob is RobotDeCombate)
                {
                    are.robotsDeCombate.Add((RobotDeCombate)rob);
                }
                else
                {
                    are.robotsSirvientes.Add((RobotSirviente)rob);
                }
            }
            return are;
        }
        //********************************************************************************
        public static Estacionamiento operator +(Estacionamiento est, Vehiculo vehi)
        {
            if (est.vehiculos.Count < est.espacioDisponible)
            {
                if (vehi.Patente != null)
                {
                    if (est != vehi)
                    {
                        est.vehiculos.Add(vehi);
                    }
                }
            }

            return est;
        }

        #endregion

        #region Operador -
        public static Arena operator -(Arena are, Robot rob)
        {
            if (are == rob)
            {
                if (rob is RobotDeCombate)
                {
                    are.robotsDeCombate.Remove((RobotDeCombate)rob);
                }
                else
                {
                    are.robotsSirvientes.Remove((RobotSirviente)rob);
                }
            }
            return are;
        }
        //********************************************************************************
        public static string operator -(Estacionamiento est, Vehiculo vehi)
        {
            string retorno = "El vehiculo no es parte del Estacionamiento";
            if (!(vehi is null))
            {
                if (est == vehi)
                {
                    retorno = vehi.ImprimirTiket();
                    est.vehiculos.Remove(vehi);
                }
            }
            return retorno;
        }
        //**********************************************************************************
        #endregion

        #region ToString
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"{this.nombre}\n");
            sb.AppendLine("Lista de robots de Combate\n*****************\n");
            foreach (RobotDeCombate item in this.robotsDeCombate)
            {
                sb.AppendLine($"{item.ServirHumanidad()}");
            }
            sb.AppendLine("Lista de robots de Servicio\n*****************\n");
            foreach (RobotSirviente item in this.robotsSirvientes)
            {
                sb.AppendLine($"{item.ServirHumanidad()}");
            }

            return sb.ToString();
        }

        public static implicit operator string(Arena arena)
        {
            return arena.ToString();
        }
        //***********************************************************************************
        public virtual string Mostrar()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"Nombre: {this.Nombre}\nApellido: {this.Apellido}\nDni: {this.Dni}\nEdad: {this.Edad}");
            return sb.ToString();
        }

        public override string Mostrar()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"{base.Mostrar()}Altura:{this.Altura}\nPeso:{this.Peso}\nPosicion{this.Posicion} ");
            return sb.ToString();

        }
        #endregion

        #region Explicit 
        public static explicit operator string(Equipo equi)
        {
            StringBuilder sb = new StringBuilder();

            if (equi.directorTecnico != null)
            {
                sb.AppendLine($"Nombre:{equi.Nombre}\nDT\n{equi.directorTecnico.Mostrar()}\n");
            }
            else
            {
                sb.AppendLine($"Nombre:{equi.Nombre}\nSin DT Asignado\n");
            }
            sb.AppendLine("Jugadores\n");
            foreach (Jugador item in equi.jugadores)
            {
                sb.AppendLine($"{item.Mostrar()}");
            }

            return sb.ToString();
        }
        //****************************************************************************************
        public static explicit operator string(Estacionamiento est)
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"Nombre:{est.nombre}\nCapacidad:{est.espacioDisponible}");
            if (est.vehiculos.Count > 0)
            {
                sb.AppendLine("Lista de Vehiculos\n===================");
                foreach (Vehiculo item in est.vehiculos)
                {
                    sb.AppendLine(item.ConsultarDatos());
                }
            }
            else
            {
                sb.AppendLine("El Estacionamiento se encuentra vacio");
            }

            return sb.ToString();
        }
        //*****************************************************************************************

        #endregion

        #region Metodos interesantes
        public bool ValidarEstadoFisico()
        {
            float imc;
            bool retorno = false;

            imc = this.Peso / (float)(Math.Pow(this.altura, 2));
            if (imc > 18.4 && imc < 25.1)
            {
                retorno = true;
            }
            return retorno;
        }

        #endregion
    }
}
