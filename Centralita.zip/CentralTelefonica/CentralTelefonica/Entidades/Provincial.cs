using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades
{
  public class Provincial : Llamada
  {
    #region Enumerado
    public enum Franja
    {
      Franja_1,
      Franja_2,
      Franja_3
    }
    #endregion

    #region Atributo
    protected Franja franjaHoraria;
    #endregion

    #region Constructores
    public Provincial(string origen, Franja miFranja, float duracion, string destino) : base(duracion, destino, origen)
    {
      this.franjaHoraria = miFranja;
    }
    public Provincial(Franja miFranja, Llamada llam):this(llam.NroOrigen,miFranja,llam.Duracion,llam.NroDestino)
    {
    }
    #endregion

    #region Propiedades
    public float CostoLlamada
    {
      get { return this.CalcularCosto(); }
    }
    #endregion

    #region Metodos
    private float CalcularCosto()
    {
      float retorno = base.Duracion * 0.66f;
      if (this.franjaHoraria == Franja.Franja_1)
      {
        retorno = base.Duracion * 0.99f;
      }
      else
      {
        if (this.franjaHoraria == Franja.Franja_2)
        {
          retorno = base.Duracion * 1.25f;
        }
      }
      return retorno;
    }

    public string mostrar()
    {
      StringBuilder sb = new StringBuilder(base.mostrar());
      sb.AppendFormat($"Franja Horaria:{this.franjaHoraria}\nCosto Llamada:{this.CostoLlamada}");

      return sb.ToString();
    }
    #endregion

  }
}
