using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades
{
  public class Local : Llamada
  {
    private float costo;

    #region Constructores
    public Local(string origen, float duracion, string destino, float costo) : base(duracion, destino, origen)
    {
      this.costo = costo;
    }

    public Local(Llamada llamada, float costo) : this(llamada.NroOrigen, llamada.Duracion, llamada.NroDestino, costo)
    {

    }
    #endregion

    #region Propiedades
    public float CostoLlamada
    {
      get
      {
        return this.CostoLLamada();
      }
    }
    #endregion

    #region Metodos
    private float CostoLLamada()
    {
      return base.duracion * this.costo;
    }


    public string Mostrar()
    {
      StringBuilder sb = new StringBuilder();

      sb.AppendFormat($"{base.mostrar()}\nCosto:{this.costo}");
      return sb.ToString();
    }
    #endregion

  }
}
