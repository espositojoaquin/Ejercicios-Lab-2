using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades
{
  public class Centralita
  {
    private List<Llamada> listaDeLlamadas;
    private string razonSocial;
    #region Cosntructores

    public Centralita()
    {
      this.listaDeLlamadas = new List<Llamada>();
    }

    public Centralita(string nombreEmpresa) : this()
    {
      this.razonSocial = nombreEmpresa;
    }

    #endregion

    #region Propieades
    public float GananciaPorLocal
    {
      get { return this.CalcularGanancia(Llamada.TipoDeLlamadas.Local);}
    }
    public float GananciaPorProvincial
    {
      get { return this.CalcularGanancia(Llamada.TipoDeLlamadas.Provincial); }
    }
    public float GananciaPorTotal
    {
      get { return this.CalcularGanancia(Llamada.TipoDeLlamadas.Todas); }
    }
    public List<Llamada> Llamadas
    {
      get { return this.listaDeLlamadas; }
    }

    #endregion

    #region Metodos
    private float CalcularGanancia(Llamada.TipoDeLlamadas tipo)
    {
      float retorno = 0;
      float auxLocal = 0;
      float auxProvincial = 0;
      float auxTodas = 0;
      foreach (Llamada item in this.Llamadas)
      {

        if (item is Local)
        {
          auxLocal += ((Local)item).CostoLlamada;
          auxTodas += ((Local)item).CostoLlamada;
        }
        else
        {
          if (item is Provincial)
          {
            auxProvincial += ((Provincial)item).CostoLlamada;
            auxTodas += ((Provincial)item).CostoLlamada;
          }
         
        }
      }
      if(tipo==Llamada.TipoDeLlamadas.Local)
      {
        retorno = auxLocal;
      }
      else
      {
        if(tipo==Llamada.TipoDeLlamadas.Provincial)
        {
          retorno = auxProvincial;
        }
        else
        {
          retorno = auxTodas;
        }
      }
      return retorno;

    }

    public string Mostrar()
    {
      StringBuilder sb = new StringBuilder();
      sb.AppendFormat($"Razon social:{this.razonSocial}\n Ganancia Local:{this.GananciaPorLocal}\nGanancia Provincial:{this.GananciaPorProvincial}\nGanancia Total:{this.GananciaPorTotal}");
      foreach (Llamada item in this.Llamadas)
      {
        sb.AppendFormat($"{item.mostrar()}");
      }
      return sb.ToString();
      
    }

    #endregion
  }
}
