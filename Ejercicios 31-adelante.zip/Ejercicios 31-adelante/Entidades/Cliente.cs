using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
  public class Cliente
  {
    private string nombre;
    private int numero;

    public string Nombre
    {
      get
      {
        return this.nombre;
      }
      set
      {
        this.nombre = value;
      }
    }

    public int Numero
    {
      get
      {
        return this.numero;
      }
    }

    public Cliente (int numero)
    {
      this.numero = numero;
    }

    public Cliente (string nombre, int numero):this(numero)
    {
      this.nombre = nombre;
    }

    public static bool operator ==(Cliente cli1,Cliente cli2)
    {
      bool retorno = false;

      if(cli1.numero==cli2.numero)
      {
        retorno = true;
      }

      return retorno;
    }

    public static bool operator !=(Cliente cli1, Cliente cli2)
    {
      return !(cli1 == cli2);
    }


  }
}
