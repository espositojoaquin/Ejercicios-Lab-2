﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;


namespace vistaForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            List<Provincia> provincias=new List<Provincia>();
            SqlConnection cn = new SqlConnection(Properties.Settings.Default.CadenaSQL);
            SqlCommand comando;
            //cn.ConnectionString = Properties.Settings.Default.CadenaSQL; Si no lo instacie en el contructor 
            //  MessageBox.Show(Properties.Settings.Default.CadenaSQL);
            comando = new SqlCommand();
            comando.Connection = cn;
            comando.CommandType= System.Data.CommandType.Text;
            comando.CommandText = "SELECT id,Nombre FROM Provincias";

            cn.Open();

            SqlDataReader oDr = comando.ExecuteReader();

            while(oDr.Read())
            {
                //oDr["nombre"].ToString();
                provincias.Add(new Provincia((int)(decimal)oDr["id"], oDr["nombre"].ToString()));
            }
            cn.Close();

            this.cmb.DataSource = provincias;

           
           


        }
    }
}
