﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ejercicio_N_38
{
    public class Sobreescrito
    {
        public override string ToString()
        {
            return "¡Este es mi ToString sobrecargado!";
        }

        public override bool Equals(object obj)
        {
         
            return !base.Equals(obj);
        }

        public override int GetHashCode()
        {
            return 1142510187;
        }

    }
}
