using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades
{
    public class Llamada
    {
        #region Enumerado
        public enum TipoDeLlamadas
        {
            Local,
            Provincial,
            Todas
        }
        #endregion

        #region Atributos
        protected float duracion;
        protected string nroDestino;
        protected string nroOrigen;
        #endregion

        #region Constructores
        public Llamada(float duracion, string nroDestino, string nroOringen)
        {
            this.nroDestino = nroDestino;
            this.nroOrigen = nroDestino;
            this.duracion = duracion;

        }
        #endregion

        #region Propiedades
        public float Duracion
        {
            get
            {
                return this.duracion;
            }
        }
        public string NroDestino
        {
            get
            {
                return this.nroDestino;
            }
        }
        public string NroOrigen
        {
            get
            {
                return this.nroOrigen;
            }
        }
        #endregion

        #region Metodos
        public virtual string Mostrar()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"Duracion: {this.Duracion} Min\nN.Origen: {this.NroOrigen}\nN.Destino: {this.nroOrigen}");
           
            return sb.ToString();
        }
        /// <summary> Compara la duracion entre dos llamadas
        /// </summary>
        /// <param name="llam1"></param>
        /// <param name="llam2"></param>
        /// <returns></returns> 1 si llam1 dura mas, -1 si llam2 dura mas, 0 si son iguales
        public int OrdenarPorDuracion(Llamada llam1,Llamada llam2)
        {
            int retorno;
            if(llam1.Duracion>llam2.Duracion)
            {
                retorno = 1;
            }
            else
            { 
                if(llam1.Duracion < llam2.Duracion)
                {
                    retorno = -1;
                }
                else
                {
                    retorno = 0;
                }

            }
            return retorno;
        }
        #endregion




    }
}
