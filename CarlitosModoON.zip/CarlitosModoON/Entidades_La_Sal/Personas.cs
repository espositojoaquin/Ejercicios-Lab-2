using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades_La_Sal
{
    public class Personas
    {
      private string nombre;
      private string apellido;
      private int dni;
      private double tarjeta;

    #region Constructores

    public Personas()
    {

    }

    public Personas(int dni)
    {
      this.dni = dni;
    }

    public Personas(string nom, string ape, int dni,double tar):this(dni)
    {
      this.Nombre = nom;
      this.Apellido = ape;
      this.tarjeta = tar;
    }

    #endregion

    #region Propiedades
    public string Nombre
    {
      set { this.nombre = value; }
      get { return this.nombre; }
    }

    public string Apellido
    {
      set { this.apellido = value; }
      get { return this.apellido; }
    }

    public int Dni
    {
      set { this.dni = value; }
      get { return this.dni; }
    }
    public double Tarjeta
    {
      set { this.tarjeta = value; }
      get { return this.tarjeta; }
    }

    #endregion

    public static bool operator ==(Personas per1,Personas per2)
    {
      return (per1.Dni == per2.Dni);
    }
    public static bool operator !=(Personas per1, Personas per2)
    {
      return !(per1 == per2);
    }

    public override string ToString()
    {
      return $"Nombre: {this.Nombre}\nApellido: {this.Apellido}\nDni: {this.Dni}\nTarjeta:{this.tarjeta}\n";
    }






  }
}
