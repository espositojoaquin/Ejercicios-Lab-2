using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades_La_Sal;

namespace FormCarli
{
  public partial class Form3 :Form
  {
    public Personas persona;
   
    public Form3()
    {
      InitializeComponent();
    }

    private void btnEliminar_Click(object sender, EventArgs e)
    {
       persona =new Personas(Convert.ToInt32(txtDni.Text));
       this.DialogResult = DialogResult.OK;
    }
  }
}
