using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades_La_Sal;

namespace FormCarli
{
  public partial class Form2 : Form
  {
    public Personas persona;
    public Form2()
    {
      InitializeComponent();
    }

    private void btnAceptar_Click(object sender, EventArgs e)
    {
      persona = new Personas(txtName.Text, txtSurname.Text, Convert.ToInt32(txtDni.Text), Convert.ToDouble(txtTarjeta.Text));

      this.DialogResult = DialogResult.OK;

      MessageBox.Show(" Carlitos Agrego Sal");
    }

    private void btnCancel_Click(object sender, EventArgs e)
    {
      this.DialogResult = DialogResult.Cancel;
    }
  }
}
