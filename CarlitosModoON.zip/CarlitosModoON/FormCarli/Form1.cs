using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades_La_Sal;
using System.Xml;
using System.Xml.Serialization;


namespace FormCarli
{
  public partial class Form1 : Form
  {
    public List<Personas> listaPersonas;

    public Form1()
    {
      listaPersonas = new List<Personas>();
      listaPersonas = this.Deserializar();
      this.IsMdiContainer = true;
      InitializeComponent();
    }

    private void btnNew_Click(object sender, EventArgs e)
    {
      Form2 form2 = new Form2();
      if (form2.ShowDialog() == DialogResult.OK)
      {
        listaPersonas.Add(form2.persona);
      }


    }

    private void rtbPersonas_TextChanged(object sender, EventArgs e)
    {

    }

    private void btnRefresh_Click(object sender, EventArgs e)
    {
      StringBuilder sb = new StringBuilder();
      foreach (Personas item in listaPersonas)
      {
        sb.AppendLine(item.ToString());
      }

      rtbPersonas.Text = sb.ToString();
    }

    private void btnEliminar_Click(object sender, EventArgs e)
    {
      Form3 form3 = new Form3();
      if (form3.ShowDialog() == DialogResult.OK)
      {
        for (int i = 0; i < listaPersonas.Count; i++)
        {
          if (listaPersonas[i] == form3.persona)
          {
            listaPersonas.Remove(listaPersonas[i]);
          }
        }

      }

    }

    private void btnGuardar_Click(object sender, EventArgs e)
    {
      string ruta = @"C:\Users\alumno\Desktop\CarlitosModoON\ListaPersonas.Xml";
      XmlTextWriter writer = new XmlTextWriter(ruta, Encoding.ASCII);
      XmlSerializer ser = new XmlSerializer(typeof(List<Personas>));
      ser.Serialize(writer, listaPersonas);
      writer.Close();
    }

    public List<Personas> Deserializar()
    {
      List<Personas> per;
      string ruta = @"C:\Users\alumno\Desktop\CarlitosModoON\ListaPersonas.Xml";
      XmlTextReader des = new XmlTextReader(ruta);
      XmlSerializer ser = new XmlSerializer(typeof(List<Personas>));
      per = (List<Personas>)ser.Deserialize(des);

      des.Close();
      return per;

    }
  }
}
