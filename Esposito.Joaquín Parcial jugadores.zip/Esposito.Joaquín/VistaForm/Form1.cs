using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Entidades;

namespace VistaForm
{
  public partial class Form1 : Form
  {
    DirectorTecnico director;
    public Form1()
    {
      InitializeComponent();
    }

    private void label4_Click(object sender, EventArgs e)
    {

    }

    private void btnCrear_Click(object sender, EventArgs e)
    {
      director = new DirectorTecnico(txtNombre.Text, txtApellido.Text,Convert.ToInt32(npdEdad.Value),Convert.ToInt32(npdDNI.Value) ,Convert.ToInt32(npdExperiencia.Value));
      MessageBox.Show("Se ha Creado el DT");

    }

    private void btnValidar_Click(object sender, EventArgs e)
    {
      if(director==null)
      {
        MessageBox.Show("Aun no se ha Creado el DT del formulario");
      }
      else
      {
        if(director.ValidarAptitud())
        {
          MessageBox.Show("El DT es Apto ");
        }
        else
        {
          MessageBox.Show("El DT no es Apto ");
        }
      }
    }
  }
}
