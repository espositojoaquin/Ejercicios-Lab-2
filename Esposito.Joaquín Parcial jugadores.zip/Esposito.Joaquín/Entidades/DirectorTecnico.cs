using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades
{
  public class DirectorTecnico:Persona
  {
    #region Atributos
    private int añosExperiencia;
    #endregion

    #region Constructores
    public DirectorTecnico(string nombre, string apellido,int edad,int dni,int añoExp):base(nombre,apellido,edad,dni)
    {
      this.AñosExperiencia = añoExp;
    }
    #endregion

    #region Propiedades
    public int AñosExperiencia
    {
      get
      {
       return this.añosExperiencia;
      }
      set
      {
        this.añosExperiencia = value;
      }
    }
    #endregion

    #region Metodos

    public override bool ValidarAptitud()
    {
      bool retorno = false;

      if(this.AñosExperiencia>1&&this.Edad<65)
      {
        retorno = true;
      }
      return retorno;
    }

    public override string Mostrar()
    {
      return base.Mostrar()+ $"Años de Experiencia{this.AñosExperiencia}";
    }
    #endregion
  }
}
