using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades
{
  public class Equipo
  {
    #region Atributos
    private const int cantidadMaximaJugador = 6;
    private DirectorTecnico directorTecnico;
    private List<Jugador> jugadores;
    private string nombre;
    #endregion

    #region Constructores
    private Equipo()
    {
      this.jugadores = new List<Jugador>();
    }

    public Equipo(string nombre) : this()
    {
      this.nombre = nombre;
    }
    #endregion

    #region Propiedades
    public DirectorTecnico DirectorTecnico
    {
      set
      {
        if (value != null)
        {
          if (value.ValidarAptitud())
          {
            this.directorTecnico = value;
          }
        }


      }
    }
    public string Nombre
    {
      get
      {
        return this.nombre;
      }
    }
    #endregion

    #region Operadores
    public static explicit operator string(Equipo equi)
    {
      StringBuilder sb = new StringBuilder();

      if (equi.directorTecnico != null)
      {
        sb.AppendLine($"Nombre:{equi.Nombre}\nDT\n{equi.directorTecnico.Mostrar()}\n");
      }
      else
      {
        sb.AppendLine($"Nombre:{equi.Nombre}\nSin DT Asignado\n");
      }
      sb.AppendLine("Jugadores\n");
      foreach (Jugador item in equi.jugadores)
      {
        sb.AppendLine($"{item.Mostrar()}");
      }

      return sb.ToString();
    }
    public static bool operator ==(Equipo equi, Jugador jug)
    {
      bool retorno = false;

      foreach (Jugador item in equi.jugadores)
      {
        if (item == jug)
        {
          retorno = true;
          break;
        }
      }
      return retorno;
    }

    public static bool operator !=(Equipo equi, Jugador jug)
    {
      return !(equi == jug);
    }

    public static Equipo operator +(Equipo equi, Jugador jug)
    {
      if (equi.jugadores.Count < Equipo.cantidadMaximaJugador)
      {
        if (equi != jug)
        {
          if (jug.ValidarAptitud())
          {
            equi.jugadores.Add(jug);
          }
        }
      }

      return equi;

    }
    #endregion

    #region Metodos
    public static bool ValidarEquipo(Equipo equi)
    {
      bool retorno = false;
      bool defensor = false;
      bool delantero = false;
      bool arquero = false;
      bool central = false;
      int auxArq = 0;
      Posicion pos;


      if (!Equals(equi.directorTecnico, null))
      {
        foreach (Jugador item in equi.jugadores)
        {
          pos = item.Posicion;
          switch (pos)
          {
            case Posicion.Arquero:
              arquero = true;
              auxArq++;
              break;
            case Posicion.Defensor:
              defensor = true;
              break;
            case Posicion.Central:
              central = true;
              break;
            case Posicion.Delantero:
              delantero = true;
              break;
          }
        }
        if (defensor && delantero && arquero && central && auxArq == 1 && equi.jugadores.Count == Equipo.cantidadMaximaJugador)
        {
          retorno = true;
        }

      }
      return retorno;

    }
    #endregion




  }
}
