using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades
{
  public class Jugador : Persona
  {
    #region Atributos
    private float altura;
    private float peso;
    private Posicion posicion;
    #endregion

    #region Costructores
    public Jugador(string nombre, string apellido, int edad, int dni, float peso, float altura, Posicion posicion) : base(nombre, apellido, edad, dni)
    {
      this.peso = peso;
      this.posicion = posicion;
      this.altura = altura;
    }
    #endregion

    #region Propiedades

    public float Altura
    {
      get
      {
        return this.altura;
      }
    }
    public float Peso
    {
      get
      {
        return this.peso;
      }
    }
    public Posicion Posicion
    {
      get
      {
        return this.posicion;
      }
    }

    #endregion

    #region Metodos
    public bool ValidarEstadoFisico()
    {
      float imc;
      bool retorno = false;

      imc = this.Peso / (float)(Math.Pow(this.altura, 2));
      if (imc > 18.4 && imc < 25.1)
      {
        retorno = true;
      }
      return retorno;
    }

    public override bool ValidarAptitud()
    {
      bool retorno = false;
      if (this.Edad < 41 && this.ValidarEstadoFisico())
      {
        retorno = true;
      }

      return retorno;
    }

    public override string Mostrar()
    {
      StringBuilder sb = new StringBuilder();

      sb.AppendLine($"{base.Mostrar()}Altura:{this.Altura}\nPeso:{this.Peso}\nPosicion{this.Posicion} ");
      return sb.ToString();

    }

    #endregion


  }
}
