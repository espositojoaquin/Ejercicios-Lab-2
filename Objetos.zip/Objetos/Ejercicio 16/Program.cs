using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Ejercicio_16
{
  class Program
  {
    static void Main(string[] args)
    {
      
      Alumno alu1 = new Alumno();
      Alumno alu2 = new Alumno();
      Alumno alu3= new Alumno();

      alu1.nombre = "Leo";
      alu1.apellido = "ElRey";
      alu1.legajo = 1254;
      alu1.Estudiar(6, 6);
      alu1.CalcularFinal();
      Thread.Sleep(1000);
      alu2.nombre = "Luquitas";
      alu2.apellido = "ElGallina";
      alu2.legajo = 1456;
      alu2.Estudiar(4, 5);
      alu2.CalcularFinal();
      Thread.Sleep(1000);
      alu3.nombre = "Luz";
      alu3.apellido = "ElCapo";
      alu3.legajo = 1756;
      alu3.Estudiar(2, 5);
      alu3.CalcularFinal();

      Console.WriteLine("\n{0}\n{1}\n{2}", alu1.Mostrar(), alu2.Mostrar(), alu3.Mostrar());
      Console.ReadKey();



    }
  }
}
