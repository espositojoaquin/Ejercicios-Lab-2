using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_16
{
  class Alumno
  {
    private byte nota1;
    private byte nota2;
    private float notaFinal;
    public string apellido;
    public int legajo;
    public string nombre;

    public void Estudiar(byte notaUno,byte notaDos)
    {
      this.nota1 = notaUno;
      this.nota2 = notaDos;
    }
    public void CalcularFinal()
    {
      Random rm = new Random();
      if(nota1>3 && nota2>3)
      {
        notaFinal = rm.Next(2, 10);
      }
      else
      {
        notaFinal = -1;
      }
    }

    public string Mostrar()
    {
      StringBuilder sb = new StringBuilder();

      sb.AppendFormat("\nNombre:{0}\nApellido:{1}\nLegajo:{2}\nNota 1:{3}\nNota 2:{4}",this.nombre,this.apellido,this.legajo,nota1,this.nota2);
      if(notaFinal==-1)
      {
        sb.AppendFormat("\nAlumno Desaprobado");
      }
      else
      {
        sb.AppendFormat("\nNota Final:{0}",this.notaFinal);
      }

      return sb.ToString();
    }


  }
}
