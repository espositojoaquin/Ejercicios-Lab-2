using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BoligrafoClase;

namespace Ejercicio_17
{
  class Program
  {
    static void Main(string[] args)
    {
      string aux;
      Boligrafo boli1 = new Boligrafo(100,ConsoleColor.Blue);
      Boligrafo boli2 = new Boligrafo(50, ConsoleColor.Red);

      boli1.Pintar(50,out aux);
      Console.ForegroundColor=boli1.GetColor();
      Console.WriteLine("{0}",aux);

      boli1.Pintar(40, out aux);
      Console.ForegroundColor = boli2.GetColor();

      Console.WriteLine("{0}", aux);

      Console.ReadKey();

    }
  }
}
