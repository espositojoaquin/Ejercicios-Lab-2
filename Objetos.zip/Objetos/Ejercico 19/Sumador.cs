using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercico_19
{
  class Sumador
  {
    private int cantidadSumas;

    public Sumador(int num)
    {
      this.cantidadSumas = num;
    }

    public Sumador():this(0)
    {
      
    }

    public  long Sumar(long a, long b)
    {
      this.cantidadSumas += 1;
      return a + b;
    }

    public  string Sumar(string a, string b)
    {
      this.cantidadSumas += 1;
      return string.Concat(a,b);
    }

    public static long operator +(Sumador sum1,Sumador sum2)
    {
      return sum1.cantidadSumas + sum2.cantidadSumas;
    }


   


  }
}
