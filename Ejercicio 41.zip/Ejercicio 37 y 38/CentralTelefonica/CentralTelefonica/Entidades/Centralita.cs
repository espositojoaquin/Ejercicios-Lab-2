using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades
{
    public class Centralita
    {
        private List<Llamada> listaDeLlamadas;
        private string razonSocial;
        #region Cosntructores

        public Centralita()
        {
            this.listaDeLlamadas = new List<Llamada>();
        }

        public Centralita(string nombreEmpresa) : this()
        {
            this.razonSocial = nombreEmpresa;
        }

        #endregion

        #region Propieades
        public float GananciaPorLocal
        {
            get { return this.CalcularGanancia(Llamada.TipoDeLlamadas.Local); }
        }
        public float GananciaPorProvincial
        {
            get { return this.CalcularGanancia(Llamada.TipoDeLlamadas.Provincial); }
        }
        public float GananciaPorTotal
        {
            get { return this.CalcularGanancia(Llamada.TipoDeLlamadas.Todas); }
        }
        public List<Llamada> Llamadas
        {
            get {
                this.OrdenarLlamadas();
                return this.listaDeLlamadas; }
        }

    #endregion

    #region Operadores
    public static bool operator ==(Centralita cen,Llamada llam)
    {
      bool retorno = false;
      try
      {
        foreach (Llamada item in cen.listaDeLlamadas)
        {
          if (item == llam)
          {
            retorno = true;
          }
        }
      }
      catch(NullReferenceException)
      {
        throw new Exception("Valores Nulos");
       
      }
      return retorno;
    }
    public static bool operator !=(Centralita cen, Llamada llam)
    {
      return !(cen == llam);
    }

    public static Centralita operator +(Centralita cen, Llamada llam)
    {
      try
      {
        if(cen!=llam)
        {
          cen.listaDeLlamadas.Add(llam);
        }
        else
        {
          throw new CentralitaExeption("Esta llamada ya esta dentro de la lista", "Centralita","+");
        }
      }
      catch(NullReferenceException e)
      {
        throw new Exception("Valores Nulos",e);
      }
    }

    #endregion

    #region Metodos
    private float CalcularGanancia(Llamada.TipoDeLlamadas tipo)
        {
            float retorno = 0;
            float auxLocal = 0;
            float auxProvincial = 0;
            float auxTodas = 0;
            foreach (Llamada item in this.Llamadas)
            {

                if (item is Local)
                {
                    auxLocal += ((Local)item).CostoLlamada;
                    auxTodas += ((Local)item).CostoLlamada;
                }
                else
                {
                    if (item is Provincial)
                    {
                        auxProvincial += ((Provincial)item).CostoLlamada;
                        auxTodas += ((Provincial)item).CostoLlamada;
                    }

                }
            }
            if (tipo == Llamada.TipoDeLlamadas.Local)
            {
                retorno = auxLocal;
            }
            else
            {
                if (tipo == Llamada.TipoDeLlamadas.Provincial)
                {
                    retorno = auxProvincial;
                }
                else
                {
                    retorno = auxTodas;
                }
            }
            return retorno;

        }

        public string Mostrar()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Razon social:{this.razonSocial}\nGanancia Local:{this.GananciaPorLocal}\nGanancia Provincial:{this.GananciaPorProvincial}\nGanancia Total:{this.GananciaPorTotal}");
            sb.AppendLine("\nLista de Llamadas\n******************\n");
            foreach (Llamada item in this.Llamadas)
            {
                sb.AppendLine($"{item.Mostrar()}");
            }
            return sb.ToString();

        }
        public void OrdenarLlamadas()
        {
            Llamada llamAux=new Llamada(1,"gf","kh");

            for (int i = 0; i < listaDeLlamadas.Count-1; i++)
            {
                for (int j= i+1; j < listaDeLlamadas.Count; j++)
                {
                    if(listaDeLlamadas[i].OrdenarPorDuracion(listaDeLlamadas[i],listaDeLlamadas[j])==1)
                    {
                        llamAux = listaDeLlamadas[i];
                        listaDeLlamadas[i] = listaDeLlamadas[j];
                        listaDeLlamadas[j] = llamAux;
                       
                    }
                }

            }
        }

        #endregion
    }
}
