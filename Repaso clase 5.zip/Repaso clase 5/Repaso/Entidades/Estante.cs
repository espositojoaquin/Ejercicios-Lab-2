using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
  public class Estante
  {
    private Producto[] productos;
    private int ubicacionEstante;

    private Estante(int capacidad)
    {
      this.productos = new Producto[capacidad];
    }

    public Estante(int capacidad, int ubicacion) : this(capacidad)
    {
      this.ubicacionEstante = ubicacion;
    }

    public Producto[] GetProductos()
    {
      return this.productos;
    }

    public static bool operator ==(Estante est, Producto pro)
    {
      bool retorno = false;
      for (int i = 0; i < est.productos.Length; i++)
      {
        if (est.productos[i] == pro)
        {
          retorno = true;
        }
      }
      return retorno;
    }
    public static bool operator !=(Estante est, Producto pro)
    {
      return !(est == pro);
    }

    public static bool operator +(Estante est, Producto pro)
    {
      bool retorno = false;
      if (est != pro)
      {
        for (int i = 0; i < est.productos.Length; i++)
        {
          if (Equals(est.productos[i], null))
          {

            est.productos[i] = pro;

            retorno = true;
          }

        }
      }

      return retorno;
    }

    public static Estante operator -(Estante est, Producto pro)
    {
      if (est == pro)
      {
        for (int i = 0; i < est.productos.Length; i++)
        {
          if (est.productos[i] == pro)
          {
            est.productos[i] = null;
          }

        }
      }
      
      return est;
    }

    public static string MostrarEstante(Estante est)
    {
      StringBuilder sb = new StringBuilder();

      for (int i = 0; i < est.productos.Length; i++)
      {
        sb.AppendFormat($"\n{est.productos[i].MostrarProducto(est.productos[i])}\n Estante:{est.ubicacionEstante}");

      }
      return sb.ToString();
    }





  }
}
