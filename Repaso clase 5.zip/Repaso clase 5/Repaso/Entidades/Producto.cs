using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
  public class Producto
  {
    private string codigoDeBarra;
    private string marca;
    private float precio;

    public string GetMarca()
    {
      return this.marca;
    }

    public float GetPrecio()
    {
      return this.precio;
    }

    public static explicit operator string(Producto P)
    {
      return P.codigoDeBarra;

    }

    public Producto(string marca, string codigo, float precio)
    {
      this.precio = precio;
      this.marca = marca;
      this.codigoDeBarra = codigo;
    }

    public static bool operator ==(Producto pro1, Producto pro2)
    {
      bool retorno = false;
      if (!Equals(pro1, null) && !Equals(pro2, null))
      {
        if (pro1.marca == pro2.marca && pro1.codigoDeBarra == pro2.codigoDeBarra)
        {
          retorno = true;
        }
      }


      return retorno;
    }
    public static bool operator !=(Producto pro1, Producto pro2)
    {
      return !(pro1 == pro2);
    }

    public static bool operator ==(Producto pro1, string marca)
    {
      bool retorno = false;
      if (pro1.marca == marca)
      {
        retorno = true;
      }
      return retorno;
    }

    public static bool operator !=(Producto pro1, string marca)
    {
      return !(pro1 == marca);
    }

    public string MostrarProducto(Producto pro)
    {
      StringBuilder sb = new StringBuilder();

      sb.AppendFormat($"Marca:{this.marca}\nCodigo:{this.codigoDeBarra}\nPrecio{this.precio}");

      return sb.ToString();
    }








  }
}
