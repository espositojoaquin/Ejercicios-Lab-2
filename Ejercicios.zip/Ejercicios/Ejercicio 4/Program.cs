﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_4
{
    class Program
    {
        static int num;
        static int cont;
        static void Main(string[] args)
        {
           while(cont<4)
            {
                for (int i = 1; i <int.MaxValue; i++)
                {
                    if(NumeroPerfecto.NumPerf(i))
                    {
                        cont++;
                        Console.WriteLine("{0}", i);
                    }
                }
            }
            Console.ReadKey();

        }
    }
}
