﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_4
{
    class NumeroPerfecto
    { 
        public static bool NumPerf(int num)
        {
            int acum=0;
            bool verif=false;

            for (int i = 1; i < num; i++)
            {
                if(num%i==0)
                {
                    acum += i;
                }
            }

            if(acum==num)
            {
                verif = true;
            }
            
            return verif;
        }
    }
}
