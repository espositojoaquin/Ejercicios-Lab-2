﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Ejercicio_2
{
    class Program
    {
        static double num;
        static double cuadrado;
        static double cubo;
        static void Main(string[] args)
        {


            Console.WriteLine("Ingresa un numero: ");
            double.TryParse(Console.ReadLine(), out num);
            while (num == 0)
            {
                Console.WriteLine("Reingresa un numero: ");
                double.TryParse(Console.ReadLine(), out num);
            }

            cuadrado = Math.Pow(num, 2);
            cubo = Math.Pow(num, 3);
            Console.WriteLine("Numero:{0}\nCuadrado: {1}\nCubo: {2}",num,cuadrado,cubo);
            Console.ReadKey();

        }
    }
}
