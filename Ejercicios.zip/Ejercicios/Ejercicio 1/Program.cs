﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_1
{
    class Program
    {
        static int num;
        static int max;
        static int min;
        static int acum = 0;
        static double prom;

        static void Main(string[] args)
        {
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("Ingrese un numero");
                int.TryParse(Console.ReadLine(), out num);
                acum += num;
                if (i == 0)
                {
                    max = num;
                    min = num;

                }
                else
                {
                    if (num > max)
                    {
                        max = num;
                    }
                    else
                    {
                        if (num < min)
                        {
                            min = num;
                        }

                    }
                }

                
            }
            prom = acum / 5;

            Console.WriteLine("maximo:{0}\nminimo:{1}\nPromedio: {2}", max, min, prom);

            Console.ReadKey();

        }
    }
}
